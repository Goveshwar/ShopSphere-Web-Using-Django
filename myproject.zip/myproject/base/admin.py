from django.contrib import admin

# Register your models here.

from .models import ProductsModel,Category

class ProductAdminModel(admin.ModelAdmin):
    list_display=['id','products_category','products_name','products_desc','products_price']

admin.site.register(ProductsModel,ProductAdminModel)


class categoryAdminModel(admin.ModelAdmin):
    list_display=['id','category_name']

admin.site.register(Category,categoryAdminModel)