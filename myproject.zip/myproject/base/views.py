from django.shortcuts import redirect, render
from .models import ProductsModel,Category,CartModel
from django.db.models import Q
# Create your views here.

def cart_count(request):
    if request.user.is_authenticated:
        return CartModel.objects.filter(host=request.user).count()

def home(request):
    trend=False
    offer=False

    if 'q' in request.GET:
        q=request.GET['q']
        try: 
            category=Category.objects.get(category_name__icontains=q)
            all_products=ProductsModel.objects.filter(products_category=category)
        except:
            all_products=ProductsModel.objects.filter(
                Q(products_name__icontains=q)|
                Q(products_desc__icontains=q)|
                Q(products_price__icontains=q)
                )
        
    elif 'category_nav' in request.GET:
        category_nav=request.GET['category_nav']
        category=Category.objects.get(category_name=category_nav)
        all_products=ProductsModel.objects.filter(products_category=category)

    elif 'trending' in request.GET:
        all_products=ProductsModel.objects.filter(trending=True)
        trend=True
    elif 'offer' in request.GET:
        all_products=ProductsModel.objects.filter(offer=True)
        offer=True
    else:
        all_products=ProductsModel.objects.all()

    all_categories=Category.objects.all()
    

    context={'all_products':all_products,'all_categories':all_categories,'trend':trend,'offer':offer,'cart_count':cart_count(request)}
    return render(request,'home.html',context)



def cart(request):
    cartProducts=CartModel.objects.filter(host=request.user)
    TA=0
    for i in cartProducts:
        TA+=i.totalprice

    return render(request,'cart.html',{'cartproducts':cartProducts,'TA':TA,'cart':True,'cart_count':cart_count(request)})


def addtocart(request,pk):
    pro=ProductsModel.objects.get(id=pk)

    try:
        c=CartModel.objects.get(Q(products_name=pro.products_name)&Q(host=request.user))
        c.quantity+=1
        c.totalprice+=pro.products_price
        c.save()
        return redirect('cart')

    except: 
        CartModel.objects.create(
                products_name=pro.products_name,
                products_desc=pro.products_desc,
                products_price=pro.products_price,
                    product_category=pro.products_category,
                    quantity=1,
                    totalprice=pro.products_price,
                    host=request.user
        )
        return redirect('cart')


def add_products(request):
  
    if request.method=='POST':
        products_category=request.POST['category']
        Product_name=request.POST.get('product_name')
        Product_desc=request.POST['product_desc']
        Product_price=request.POST['product_price']
        Product_image=request.FILES.get('product_image','Default.jpg')
        print(products_category,Product_name,Product_desc,Product_price,Product_image) 

        category_instance=Category.objects.get(category_name=products_category)      

        ProductsModel.objects.create(
            products_category=category_instance,
            products_name=Product_name,
            products_desc=Product_desc,
            products_price=Product_price,
            products_image=Product_image
        )

        return redirect('home')
    
    all_categories=Category.objects.all()


    return render(request,'add_products.html',{'all_categories':all_categories})


def increase_quantity(request, pk):
    cart_item = CartModel.objects.get(id=pk)

    cart_item.quantity += 1
    cart_item.totalprice = cart_item.products_price * cart_item.quantity
    cart_item.save()

    return redirect('cart')


def decrease_quantity(request, pk):
    cart_item = CartModel.objects.get(id=pk)

    if cart_item.quantity > 1:
        cart_item.quantity -= 1
        cart_item.totalprice = cart_item.products_price * cart_item.quantity
        cart_item.save()
    else:
        cart_item.delete()

    return redirect('cart')