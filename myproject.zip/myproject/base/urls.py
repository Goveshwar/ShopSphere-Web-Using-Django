
from django.urls import path
from .import views

urlpatterns=[
    path('',views.home,name='home'),
    path('add_products',views.add_products,name='add_products'),
    path('cart',views.cart,name='cart'),
    path('addtocart/<int:pk>',views.addtocart,name='addtocart'),
    path('increase/<int:pk>/', views.increase_quantity, name='increase'),
    path('decrease/<int:pk>/', views.decrease_quantity, name='decrease'),
]